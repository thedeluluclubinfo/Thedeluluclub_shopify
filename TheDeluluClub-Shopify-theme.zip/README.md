# The Delulu Club Shopify theme

A responsive Shopify Online Store 2.0 theme direction based on the approved homepage concept. It uses the supplied Delulu Club logo and original front and back T-shirt mockups.

## Included

- Desktop and mobile homepage with the cream, cobalt, orange, and black visual system
- Editable announcement, navigation, hero, featured drop, manifesto, and footer sections
- Product, collection, and cart templates with Shopify product and checkout forms
- Starter mockup cards that remain visible until a collection is selected in the theme editor

## Before selling

Add the real products, prices, size and colour variants, product photos, inventory, and policies in Shopify. Choose the Drop 1 collection in the Featured drop section, then replace the starter cards with the live collection. Review shipping, returns, taxes, payment setup, and mobile layout before publishing.

## Upload

Upload the packaged theme ZIP through **Online Store → Themes → Add theme → Upload zip file**. Shopify keeps it unpublished so it can be previewed before launch.
